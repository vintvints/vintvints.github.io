<style>
	/*Footer*/

.footer-bottom{
	min-height:50px;
	//background:#080808;
	background-image: -khtml-gradient(linear, left top, left bottom, from(rgb(06,07,09)), to(#000000));
	background-image: linear-gradient(rgb(06,07,09), #000000);
	text-align:center;
	padding-top:20px;
	padding-bottom:20px;
	font-size:1.2em;
	color:#d8d8d8;
	border:none !important;
}

.footer{
	min-height:90%;
	//background-color:#011010;
	background-image: -khtml-gradient(linear, left top, left bottom, from(rgb(16,17,19)), to(rgb(06,07,09)));
	background-image: linear-gradient(rgb(16,17,19), rgb(06,07,09));  
	padding-top:170px !important;
	border-bottom:none !important;
	padding-bottom:150px;
}
.footer-logo p{
	color:#f8f8f8;
	padding:10px;
	margin:10px;
	font-family:calibri;
	font-size:1.4em;
	margin-left:0px;
}
.footer-logo-image{
	width:60%;
}
.social-menu{
	color:#a8a8a8 ;
	font-size:1.9em;
	text-transform:upper;
	border-bottom:0px solid #a8a8a8;
	text-align:left;
	//width:80%;
}
.footer-menu{
	padding:20px;
}
.footer-menu ul{
	list-style-type:none;
	padding-left:0px;
	text-align:left;
}
.footer-menu ul li{
	margin:10px;
	margin-left:0px;
	color:#f8f8f8;
}
.footer-menu ul li a{
	color:#f8f8f8;
	font-size:1.2em;
}
.footer-menu ul li a .fa{
	margin-right:20px;
}
@media (max-width:600px){
	.footer-menu ul li a{
		font-size:1.2em !important;
	}
	.footer-menu ul{
		//text-align:left !important;
	}
	.footer-menu{
		//text-align:left !important;
	}
}

.text ul{
	padding:20px !important;
	margin-left:40px !important;
}
.text ul li{
	font-size:1.1em;
}
.text{
	padding:14px;
	text-align:left;
	font-size:1.4em !important;
	text-align:justify !important;
	font-family:calibri light !important;
}
</style>
	<footer class="navbar footer">
		<div class="container">
			<div class="col-md-12">
				<div class="col-md-3 col-xs-12">
					<div class="footer-menu">
						<span class="social-menu">MENU</span><br>
						<ul class="col-xs-12">
							<li><a class="nav-a" href="index.php"> Home </a></li>	
							<li><a class="nav-a" target="blank" href="music.php"> Music</a></li>
							<li><a class="nav-a" target="blank" href="more_about_us.php"> Contact Us</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-3 col-xs-12">
					<div class="footer-menu">
						<span class="social-menu">SUB-MENU</span><br>
						<ul class="col-xs-12">
							<li><a href="page_academy.php"> Academy </a></li>
							<li><a href="page_hireservice.php"> Hire services </a></li>
							<li><a href="page_photostudio.php"> Photo Studio </a></li>
							<li><a href="page_mastering.php"> Mastering </a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-3 col-xs-12">
					<div class="footer-menu">
						<span class="social-menu">SOCIAL</span><br>
						<ul class="col-xs-12">
							<li><a title="Social Media" href="#"> Youtube</a></li>
							<li><a title="Social Media" href="#"> Instagram</a></li>
							<li><a title="Social Media" href="#"> Facebook</a></li>
							<li><a title="Social Media" href="#"> Twitter</a></li>
							<li><a title="Social Media" href="#"> G-Mail</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-3 col-xs-12">
					<div class="footer-menu">
						<span class="social-menu">Contact Us</span><br>
						<ul class="col-xs-12">
							<li><strong style="color:#ff0000;">Our Contact Info</strong></li>
							<li><span class="fa fa-phone" style="color:#ff0000;"></span> 0711198108</li>
							<li><span class="fa fa-envelope" style="color:#ff0000;"></span> email@emailkenya.com</li>
							<br>
							<li>Contact us <a data-toggle="collapse" href="#collapseform"><strong style="color:#ff0000;"> via our email</strong></a></li>
						</ul>
					</div>
				</div>	
			</div>
		</div>
	</footer>
	<footer class="footer-bottom">
		<div class="container">
			<span>&copy 2019 Probeatz Kenya. All Rights Reserved | Developed by  <a href="http://localhost/0%20sites/c_connect/" target="_blank" title="App and Web Developer @ +254 790304750" style="color:#ff0000;"> By Antony.K </a></span>
		</div>
	</footer>
	<div style="width:100%;overflow:hidden;">
		<div style="overflow:hidden;width:100%;height:0px;border-bottom:20px solid #eb0303;border-left:1500px solid #000000;"></div>
	<div/>
	
	
	
<script>
	  
	  var a1 = $('#my-slider').height();
	  var a2 = $('#cont-1').height();
	  var a3 = $('#cont-2').height();
	  
	  var a1a2= a1 + a2;
	  var a1a2a3= a1 + a2 + a3;
	  
	  //document.getElementById('inner').innerHTML= a1a2a3;
	  
	  
$(document).ready(function() {  
  $(window).scroll(function () { 
      console.log($(window).scrollTop())

	  
    if ($(window).scrollTop() < a1) {
		$('#side-indicators-ul').addClass('li-1');	  
		$('#side-indicators-ul').removeClass('li-2');	  
		$('#side-indicators-ul').removeClass('li-3');	  
		$('#side-indicators-ul').removeClass('li-4');	  
    }
	if ($(window).scrollTop() > a1) {
		$('#side-indicators-ul').removeClass('li-1');	  
		$('#side-indicators-ul').addClass('li-2');	  
		$('#side-indicators-ul').removeClass('li-3');	  
		$('#side-indicators-ul').removeClass('li-4');	  
    }
	if ($(window).scrollTop() > a1a2) {
		$('#side-indicators-ul').removeClass('li-1');	  
		$('#side-indicators-ul').removeClass('li-2');	  
		$('#side-indicators-ul').addClass('li-3');	  
		$('#side-indicators-ul').removeClass('li-4');	  
    }
	if ($(window).scrollTop() > a1a2a3) {
		$('#side-indicators-ul').removeClass('li-1');	  
		$('#side-indicators-ul').removeClass('li-2');	  
		$('#side-indicators-ul').removeClass('li-3');	  
		$('#side-indicators-ul').addClass('li-4');	  
    }
  });
});
</script>