<style>
.navbar-white{
	background-color: rgb(5,5,5,.9) !important;
	background-image: -moz-linear-gradient(top, #ffffff, rgb(250,250,250));
	background-image: -ms-linear-gradient(top, #ffffff, rgb(250,250,250));
	border-bottom:1px solid rgb(0,0,0,.8) !important;
	
}
@media (min-width: 799px){
	.md-hidden{
		display:none;
	}
}	
@media (max-width: 800px){
	.xs-hidden{
		display:none;
	}
	.top-bar{
		display:none;
		/*
		padding-top:0px !important;
		height:35px !important;
		text-align:right;
		margin-top:-10px;
		position:relative !important;
		top:0px;
		padding-top:5px;
		*/
	}
	.icons-bar{
		padding-top:9px !important;
		padding-bottom:0px !important;
		width:100%;
		text-align:center;
		width:100%;
	}
	.icons-bar li{
		width:15%;
		padding-left:0px;
		padding-right:0px;
		text-align:left;
	}
	.icons-bar li a{
		font-size:1.8em !important;
	}
	
	.col-xs-12{
		text-align:left !important;
	}
	.align-left{
		text-align:left !important;
	}
	.align-left a{
		margin:20px;
		margin-left:20px !important;
		float:right !important;
	}
	.logo{
		padding-top:15px !important;
		text-align:left !important;
	}
	.logo small{
		font-size:0.5em !important;
	}
	.nav-list{
		padding:0px !important;
		padding-top:15px !important;
	}
	.nav-list li:nth-child(3){
		visibility:hidden;
	}
	.navbar-right{
		padding-top:0px !important;
		margin:0px !important;
		text-align:left !important;
		padding:0px !important;
		//border-top:1px solid #d8d8d8;
	}
	.navbar-right a{
		font-size:1.2em !important;
	}
	.logo img{
		height:70px !important;
		transition:all 1s ease;
	}
	.navbar-default{
		padding:0px !important;
		//height:70px !important;
	}
	.item .col-md-12-dark{
		padding-top:80px !important;	
		text-align:center;
	}
	.p-top{
		text-align:left;
	}
	.p-top small{
		font-size:0.8em !important;
	}
	.p-top strong{
		font-size:0.7em !important;
	}
	.text-body{
		font-size:0.9em !important;
		text-align:justify !important;
	}
	.navbar-red-top{
		background-color:#113333 !important;
	}
	.collapse .navbar-left{
		visibility:hidden !important;
		height:1px !important;
		transition:all 0s ease !important;
	}
	.my-angle-right{
		
		padding-top:10px;
		padding-bottom:20px;
		//margin-right:0px;
		//padding-right:0px;
		//margin-right:0px;
		
		background:#ffffff !important;
		position:relative !important;
		margin-left:-10px;
		
		//right:0px;
		//padding-left:200px;
		//padding-right:7%;
		//top:2px;
	}
	.nav-item a{
		color:#012323 !important;
	}
	.nav-item a small i{
		color:#012323 !important;
	}
	.nav1{
		padding-bottom:20px !important;
	}
	.slanting{
		left:0px !important;
		padding-left:0px !important;
		top:2px;
		bottom:2px;
		padding-top:0px !important;
		text-align:center;
		position:relative !important;
		background-image:none !important;
	}
	.navbar-ul li a img{
		width:
	}
}


body{
	margin:0px;
	padding:0px;
	font-size:1.13em;
	opacity:1;
	border:none !important;
}



.navbar{
	border-radius:0px !important;
	margin:0px !important;
	padding:0px !important;
	padding-bottom:20px !important;
	//border:none;
	
}

.nav1{
	background-color: hsl(0, 69%, 22%) !important;
	background-image: -moz-linear-gradient(top, #ffffff, #e8e8e8);
	background-image: -ms-linear-gradient(top, #ffffff, #e8e8e8);
	padding-top:0px;
	padding-bottom:0px;
}

.navbar-dark-top{
	height:63px;
	right:0px;
	padding-top:7px;
	padding-left:10px;
	position:relative;
	//background-color: #dc3545;
	//background-color: #ffffff;
	border-top:1px solid #000;
	border-bottom:1px solid #000;
	margin-top:-11px;
	margin-right:10px;
}
.navbar-dark-top ul{
	//background-color: #012323;
}
.navbar-dark-top ul li{
	list-style-type:none;
	display:inline-block;
	padding:10px;
	color:#012323;
	border-left:1px solid #012323;
}
.navbar-dark-top ul li:nth-child(1){
	border-left:0px solid #fff;
}
.navbar-dark-top ul li:nth-child(4){
	//border-right:1px solid #fff;
}
.navbar-dark-top ul li a{
	color:#012323 !important;
	text-decoration:none;
	font-weight:500px;
	font-size:1.12em;
	font-family:calibri;
	//border-left:1px solid #fff;
	padding-left:5px;
}
.navbar-red-top{
	min-height:60px;
	width:100%;
	//background-color: #dc3545;
	background-color: #cb1525;
	//background-color: #012323;
	border:none;
	border-bottom:1px solid #880000;
}
.navbar-red-top ul{
	margin-left:-50px;
}
.navbar-red-top ul li{
	list-style-type:none;
	display:inline-block;
	padding:10px;
	color:#f8f8f8;
}
.navbar-red-top ul li a{
	color:#f8f8f8;
	text-decoration:none;
	font-weight:500px;
	font-size:1.22em;
	font-family:calibri;
}


.navbar-white{
	margin-top:0px;
	min-height:100px;
	width:100%;
	background-color: #dc3545;
	border:none;
}

.navbar-hide{
	position:fixed;
	top:0px;
	width:100%;
	z-index:1000;
	
}

.active{
	color:#ff0000 !important;
}
.active a{
	color:#ff0000 !important;
	font-family:calibri !important;
	border-bottom:3px solid #ff0000;
}
.nav-list{
	padding-top:15px;
	padding-bottom:0px;
	display:inline-block;
}
.nav-item{
	list-style-type:none;
	display:inline-block;
	color:#012323 !important;
	font-size:1.02em;
	margin:9px;
	margin-bottom:-3px;
	margin-left:16px;
}

.nav-item a{
	color:#ffffff;
	font-size:1.22em;
	font-family:Bahnschrift SemiBold;
	text-decoration:none;
}
.my-body{
	border:none !important;
	background:none !important;
}
.nav-item a:hover{
	color:#ff0000 !important;
}
.top-bar{
	text-align:right;
	background:#bb0515;
	//z-index:1000;
	padding:0px;
	margin:0px;
}
.icons-bar{
	padding:0px;
	padding-top:9px;
}
.icons-bar li{
	display:inline-block;
	list-style-type:none;	
	color:#ffff00;
}
.icons-bar li a{
	color:#ffffff;
	padding-right:20px;
	margin-right:10px;
	font-size:1.1em;
}
.icons-bar li:nth-child(5) a{
	padding-right:0px;
	margin-right:10px;
}
.nav-item a small i{
	color:#ffffff;
	margin-right:10px;
}	

.navbar-header{
	//z-index:1000;
}
.navbar-header button{
	border:1px solid #686868;
	color:#585858 !important;
}
.icon-bar{
	background:#686868;
	color:#686868;
}
div{
	border:none;
}
.nav ul li{
	display:inline-block !important;
}



.my-angle-right{
	
	//background-color: hsl(0, 69%, 22%) !important;
  
	
	//background-image: linear-gradient(130deg,#06233C, 78%,#00090F);
	//border-color: #5e1111 #5e1111 hsl(0, 69%, 17%);
  	
	padding-top:10px;
	margin-right:0px;
	padding-right:0px;
	margin-right:0px;
	background-image: -webkit-linear-gradient(130deg,#06233C 78%,#ffffff 0%);
	//background-image:-webkit-linear-gradient(130deg,#012323 78%,rgba(0,0,0,0)0%);
	position:absolute;
	right:0px;
	padding-left:200px;
	padding-right:7%;
	top:1px;
	
}
.my-angle-right2{	
	padding:0px;
	margin:0px;
	background-image:-webkit-linear-gradient(-130deg,#012323 78%,rgba(0,0,0,0)0%);
	position:absolute;
	right:0px;
	padding-left:150px;
	padding-right:7%;
	top:90px !important;
	//z-index:100;
	display:none;
}
.search-bar ul li{
	display:inline-block;
	list-style-type:none;
}
.search-bar ul li i{
	font-size:1.4em;
	margin-left:20px;
}


.small-top{ 
	width:100%;
	margin-top:0px;	
	border-bottom:0px solid #d8d8d8; 
	float: left; 
	width: 100%; 
	background: none;
	border:none !important;
	//background-color:rgb(26,27,29);
	
}
.small-top .social-icon{
	//border-radius:0px 0px 3px 3px;
	float: right;	
	
}
.small-top .social-icon a {
	border-left: 0px solid #2b2b2b; 
	color: #eD2A03; 
	float: left; 
	padding:12px 25px;
	font-size:1.3em;
	border-bottom:0ps solid #f8f8f8;	
}
.small-top .social-icon a:last-child {border-right: 0px solid #2b2b2b;}
.small-top .social-icon a:hover {color:#FD3A13; text-decoration: none;}
.small-top .date-sec {font-size: 13px; font-weight: 600; float: left; margin-top: 4px; color: #ff8989}

.navbar-ul{
	list-style-type:none;
	padding-top:20px;
}
.navbar-ul li{
	display:inline-block;
	margin:10px;
}
.hover-mail{
	z-index:1000;
	position:fixed;
	bottom:5%;
	right:5%;	
	padding:10px;
	background:none;
	transition:all 1s ease;	
}
.hover-mail .a-1{
	background:#ff0000;
	border:1px solid #550000;
	box-shadow:0px 1px 2px 0px #550000;
	color:#ffffff;
	font-size:1.6em;
	padding:10px;
	padding-bottom:0px;
	border-radius:50%;
	width:40px;
	height:30px;
}
.hover-mail ul{
	padding-left:7px;
	border:none;
	box-shadow:none;
}
.hover-mail ul li{
	margin-bottom:10px;
}
.hover-mail ul,li{
	background:none !important;
}
.hover-mail ul li a{
	background:#000000;
	border:1px solid #550000;
	box-shadow:0px 1px 2px 0px #550000;
	color:#ffffff;
	font-size:1.5em;
	padding:13px;
	border-radius:50%;
	width:50px;
	height:50px;
}

.animated-popup {
    .a-1 {
      transition: background-color 0.0625s cubic-bezier(0.28, 0, 0.99, -0.01);
    }
    .dropdown-menu {
        width: 0;
        min-width: 100%;
        display: block;
        top: 0;
        z-index: -1;
        transition: height 0.375s ease,width 0.375s ease,min-width 0.375s ease,opacity 0.125s ease 0.0625s,top 0.0625s ease 0.375s,bottom 1s ease  0.375s,z-index 1.375s ease;
        opacity: 0;
        li {
          height: 0;
          opacity: 0;
          overflow:hidden;
          transition: opacity 0.125s ease, height 0.375s ease;
        }
    }
}

@keyframes wiggle{
	0% {transform:rotate(0deg);}
	80% {transform:rotate(0deg);}
	85% {transform:rotate(30deg);}
	95% {transform:rotate(-30deg);}
	100% {transform:rotate(0deg);}
}
.a-1{
	padding-top:10px !important;
	padding-bottom:10px !important;
}
.a-1 i{
	animation:wiggle 4.5s infinite !important;
}
.a-1:hover i{
	//animation:none !important;
	animation:wiggle 20.5s infinite !important;
	//-webkit-transform:rotate(540deg) !important;
	//transform:rotate(540deg)!important;
	//transition:all 2s ease !important;
}
</style>
<div id="fix-top" style="transition:all 1s ease;position:fixed;top:0px;width:100%;background:linear-gradient(#000000,rgba(0,0,0,.5));z-index:1000 !important;"> 	
	<div class="container">
		<div class="navbar-left col-xs-6">
			<div class="logo" style="padding-top:10px;padding-bottom:px;">
				<div style="font-family:calibri;font-size:2.0em;font-weight:bold;color:#484848;margin-top:0px;">
					<a href="index.php">
						<label style="color:#f8f8f8;padding-top:20px;font-family:Bahnschrift Condensed;">
							<span style="font-size:1.5em;">ProBeatz</span><span style="color:#ff0000;"> Kenya</span>
						</label>
					</a>	
				</div>
			</div>
		</div>
		<div class="navbar-right col-xs-6">
			<ul class="navbar-ul" style="float:right;">
				<li><a href="#"><img src="images/fx/social-facebook" style="width:40px;"/></a></li>
				<li><a href="#"><img src="images/fx/social-instagram" style="width:40px;"/></a></li>
				<li><a href="#"><img src="images/fx/social-youtube" style="width:40px;border-radius:10px;"/></a></li>
			</ul>
		</div>		
	</div>		
</div>			
<div class="hover-mail btn-group dropup animated-popup">
	<a type="button" class="dropdown-toggle a-1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="glyphicon glyphicon-menu-up"></i></a>
	<ul class="dropdown-menu">
		<li><a href="#"><i class="glyphicon glyphicon-globe"></i></a></li>
		<li><a href="#"><i class="glyphicon glyphicon-link"></i></a></li>
		<li><a href="#"><i class="glyphicon glyphicon-envelope"></i></a></li>
	</ul>
</div>

<script>
    $('#toggleNavPosition').click(function() {
      $('body').toggleClass('fixed-nav');
      $('nav').toggleClass('fixed-top static-top');
    });
</script>
<script>
    $('#toggleNavColor').click(function() {
      $('nav').toggleClass('navbar-dark navbar-light');
      $('nav').toggleClass('bg-dark bg-light');
      $('body').toggleClass('bg-dark bg-light');
    });
</script>
<script>
$(document).ready(function() {  
  $(window).scroll(function () { 
      console.log($(window).scrollTop())
    if ($(window).scrollTop() > 70) {
      $('#fix-top').addClass('navbar-hide');
	  
    }
    if ($(window).scrollTop() < 70) {
      $('#fix-top').removeClass('navbar-hide');	   
    }
  });
});
</script>
