<?php ?>
<div class="col-md-12">
				<div class="col-md-12 you-body">
					<ul>					
						<li>
							<div class="col-md-2">
								<img style="height:70px;" src="images/hqdefault.jpg"/>
							</div>
							<div class="col-md-10">
								<div class="col-md-12">
									<div class="col-md-10">
										<p>name ft name-x</p>
										<audio style="width:100%;" muted controls>
											<source src="audio/Cocoa_Tea_-_Hurry_Up_&_Come.mp3" type="audio/mp3">
											Your browser does not support the audio
										</audio>											
									</div>
									<a class="col-md-1" href="#" style="padding-top:30px;">
										<span class="col-dark glyphicon glyphicon-download" style="font-size:1.1em;margin-left:10px;color:#cb1525;padding-left:10px;"></span>
									</a>
								</div>
							</div>							
						</li>
						
					</ul>
				</div>				
			</div>