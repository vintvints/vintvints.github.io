<style>
#fix-top{
	position:relative !important;
	background-color:rgb(0,0,0,1) !important;
	z-index:1;
}
h2{
	font-weight:bold !important;
	font-size:1.4em;
}

@media (max-width: 800px){
	.sub-navbar a{
		font-size:1.5em !important;
		margin:20px !important;
		height:50px !important;
	}
	.sub-navbar strong{
		font-size:2em !important;
	}
}
.sub-navbar a,strong,span{
	color:#ffffff;
}
.sub-navbar a{
	font-family:Bahnschrift SemiBold !important;
	font-size:0.8em;
}
.sub-navbar a span{
	visibility:hidden;
}
.my-body{
	border:none !important;
}
.navbar{
	border-radius:0px !important;
}
//background:#012323
.slanting a{
	color:#ffffff;
	font-weight:200px;
	
}
body{
	background-color:#e8e8e8;
}
.cont-num{
	box-shadow:0px 1px 2px 0px #c8c8c8;
	border-left:1px solid #d8d8d8;
	border-right:1px solid #d8d8d8;
	background-color:#ffffff;
	padding-top:0px;
	padding-left:0px;
	padding-right:0px;
	background:none;box-shadow:none;border:none;
}	
.navbar-tt {
  background-color: hsl(0, 69%, 22%) !important;
  background-repeat: repeat-x;
  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#06233C", endColorstr="#00090F");
  background-image: -khtml-gradient(linear, left top, left bottom, from(#06233C), to(#00090F));
  background-image: -moz-linear-gradient(top, #06233C, #00090F);
  background-image: -ms-linear-gradient(top, #06233C, #00090F);
  background-image: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #06233C), color-stop(100%, #00090F));
  background-image: -webkit-linear-gradient(top, #06233C, #00090F);
  background-image: -o-linear-gradient(top, #06233C, #00090F);
  background-image: linear-gradient(#06233C, #00090F);
  border-color: #5e1111 #5e1111 hsl(0, 69%, 17%);
  color: #fff !important;
  text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.33);
  -webkit-font-smoothing: antialiased;
}
.outer{
	overflow:hidden;
	padding-bottom:0px;
	background:none;
	background-color:rgb(16,17,19);
	z-index:100;
	position:relative;	
	margin:0x;
	border-bottom:0px solid rgb(16,17,19);
}
.sub-bar{
	background:#eb0303;
	padding-top:20px;
	padding-bottom:20px;
	position:relative;
	margin-top:0px !important;
	//width:105%;
	border:none;
	border-width:0 0 25px 25px;
	transform:rotate(0deg);
	//z-index:1000;
}
.sub-bar .container{
	transform:rotate(0deg);
}
.sub-navbar a{
	font-size:1.5em;
	margin:10px;
	font-weight:bold;
	color:#ff3545;
	//color:#c8c8c8;
	font-family:calibri !important;
}
.sub-navbar a:hover{
	color:rgb(36,37,39);
}
.outer-bottom{
	min-height:0px;	
}
.body{
	background:#e1e8f1;
	margin-top:0px;
	padding-bottom:200px;
}
.img-5{
	//width:250px;
	height:200px;
	padding:0px;
	border:1px solid #686868;
	box-shadow:0px 1px 2px 1px #a9a9a9;
	margin-right:10px;
	text-align:left;
	margin-top:25px;
}
.text{
	text-align:left;
}
</style>

<div class="outer">
	<div class="sub-bar" style="margin:0px;height:250px;background-image:url('<?php echo $imagep?>');">
		<div class="container">
			<div class="sub-navbar" style="margin-top:70px;background:none;">
				<a href="index.php" style="font-family:calibri light;">Home</a><span> | </span>
				<a href="page_academy.php" style="font-family:calibri light;"> Academy</a><span> | </span>  
				<a href="page_photostudio.php" style="font-family:calibri light;"> Photo Studio</a><span> | </span>
				<a href="page_hireservice.php" style="font-family:calibri light;">Hire service</a><span> | </span>
				<a href="page_mastering.php" style="font-family:calibri light;"> Mastering</a><span> | </span>
				<a href="music.php" style="font-family:calibri light;"> Music Hub</a><span> | </span>
				<a href="more_about_us.php" style="font-family:calibri light;"> Contact Us</a><span> | </span>
			</div><br>	
			<div class="sub-navbar" style="margin-top:10px;background:none;">
				<strong style="color:#ffffff;font-weight:bold;font-size:1.4em;"> Samzido </strong>
				<span style="font-size:0.95em;color:#ffffff;" class="glyphicon glyphicon-menu-right"></span>
				<span style="font-size:0.95em;color:#ffffff;" class="glyphicon glyphicon-menu-right"></span>
				<span style="font-size:1.3em;"> <?php echo $titlep ?> </span>
			</div>	
		</div>
	</div>
</div>
