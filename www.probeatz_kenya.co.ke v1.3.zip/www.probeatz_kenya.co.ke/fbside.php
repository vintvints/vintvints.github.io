<style>
.fb-side{
	border:1px solid #a8a8a8;
	background:#ffffff;
	min-height:200px;
	margin-top:20px;
	padding-top:10px;
}
</style>
<div class="col-md-3 col-xs-12">
	<img class="col-md-12 col-xs-12" src="images/samzips.jpg" style="margin-top:20px;border:1px solid #989898;padding:0px;box-shadow:0px 1px 2px 1px #a9a9a9;"/>		
	<div class="col-md-12 col-xs-12 fb-side">
		<div id="fb-root"></div>
		<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v3.3"></script>
		<div class="fb-page" data-href="https://www.facebook.com/facebook" data-tabs="timeline" data-width="" data-height="" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
			<label cite="https://www.facebook.com/samuelprobeatz" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/samuelprobeatz" style="font-size:1.5em;color:#484848;">Facebook</a></label>
		</div>
	</div> 
</div>
