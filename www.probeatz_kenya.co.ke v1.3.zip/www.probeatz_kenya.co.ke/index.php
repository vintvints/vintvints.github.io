<?php include"header.php"?>
<style>
.nav-list li:nth-child(1),a{
	//color:#ff0000 !important;
}
.nav-list li:nth-child(1){
	color:#ff0000 !important;
	font-family:calibri !important;
	border-bottom:3px solid #ff0000;
}
.navbar-left{
	text-align:left;
}
.navbar-right{
	text-align:right;
}
.my-body{
	background:rgb(255,255,255);	
	border:1px solid rgb(150,150,150);
	font-size:1.26em;
	font-family:calibri;
}
.logo-image{
	height:50px;
	position:relative;
	z-index:1000;
}
.panel{
	min-height:355px;
	padding:2px !important;
	background:#ffffff;	
	border-bottom:none;
	box-shadow:none;
	margin:0px;
	margin-top:20px;
	text-align:center;
	margin-bottom:20px;
	border-radius:0px 4px 4px 0px !important;

}
.panel .col-md-12{
	padding-bottom:30px;
}
.panel-img{
	height:135px;
	width:165px;
	border-radius:50%;
	//margin-left:25% !important;
	padding:0px !important;
	background:#ffffff;	
	border-bottom:1px solid #a8a8a8;
	box-shadow:0px 1px 3px 0px #888888;
	margin-top:20px;
}
.fixed-bar{
	position:fixed;
	top:0px;
	height:70px;
	width:100%;
	z-index:1000;
}
.b-body{
	min-height:800px;
	background-color:#ffffff;
}
.img-prof{
	width:100%;
	height:150px;
}

.form-conrol{
	border:1px solid #a9a9a9;
	border-radius:5px 0px 0px 5px;
	font-size:0.9em;
	padding:5px;
	padding-left:10px;
	color:#989898;
}
.btn-form{
	border:1px solid #a9a9a9;
	border-radius:0px 5px 5px 0px;
	font-size:0.9em;
	padding:6px;
	padding-top:7px;
	color:#f8f8f8;
	margin-left:-6px;
}

.app-form{
	height:400px;
	background:rgb(255,255,255);	
	border:1px solid rgb(150,150,150);
	padding:0px;
}

.form-title{
	width:100%;
	margin:0px;
	padding:10px;
	padding-left:30px;
	color:#ffffff;
	background-color:#fe2535;
	font-size:1.32em;
	font-family:calibri;
}
.form-body{
	width:100%;
	margin:0px;
	padding:10px;
	padding-top:20px;
	padding-left:30px;
}
.form-conrol1{
	border:1px solid #c8c8c8;
	border-radius:2px;
	font-size:0.9em;
	padding:5px;
	padding-left:10px;
	font-family:calibri light;
	color:#989898;
	margin-bottom:10px;
	width:93%;
}

.btn-submit {
	width:93%;
	padding:5px;
	margin-top:20px;
	color: #fff;
	background-color: #fe3545;
	border-color: #dc3545;
	font-size:1.13em;
}
.btn{
	//border-radius:2px;
}
.btn-play {
	//width:93%;
	padding:5px;
	height:40px;
	color: #ff3545;
	background-color: #fff;
	border-color: #dc3545;
	font-size:1.03em;
	font-family:calibri light;
	margin-left:20px;
	margin-top:20px;
}
.btn-like {
	padding:2px;
	height:25px;
	color: #dc3545;
	background-color: #fff;
	border-color: #dc3545;
	font-size:0.73em;
	margin:2px;
	//position:absolute;
	right:0px;
}


.latest-release{
	margin-bottom:10px;
	//border:1px solid #f8f8f8;
	min-height:60px;
}
.title{
	color:#ffffff;
	font-size:1.4em;
	font-family:calibri;
	padding-top:20px;
}
.text{
	font-size:0.9em;
	font-family:calibri;
	line-height:18px;
}
.song-detail{
	padding-top:10px;
}
.song-detail img{
	height:60px;
	width:60px;
}

.top-title{
	background:rgb(255,255,255,.9);
	position:relative;
	top:-355px;
	padding:15px;
	width:100%;
	font-size:1.12em;
}
.bottom-title{
	background:rgb(255,255,255,.5);
	position:relative;
	top:-115px;
	padding:15px;
	width:100%;
	font-size:1.12em;
}
.text-body{
	font-family:calibri light;
	font-size:1.0em;
	padding:2px;
	padding-top:10px;
	text-align:justify;
}
.text i{
	color:#ffffff;
	margin-right:10px;
	font-size:1.23em;
}

blockquote{
	padding:0px;
	padding-left:10px;
	border-left:5px solid #ff2323;
	margin-top:0px;
	margin-left:-5px;
	color:#ff2323;
	font-size:1.3em;
	font-style:bold;
}

.navbar-left a{
	color:#012323;
	font-size:0.95em;
	margin-right:10px;
	font-weight:;
}
.navbar-left a:hover{
	color:#ff0000;
}
.navbar-left strong{
	font-size:1.3em;
}

#nav_a li{
	display:inline-block;
}

@media(max-width:800px){
	.img-main{
		visibility:hidden;
		height:0px !important;
		transition:all .5s ease;
		margin:0px;
	}
	.img-main2{
		height:350px !important;
		transition:all .5s ease;
		margin:0px;
	}
}
@media(min-width:800px){
	.img-main{
		transition:all .5s ease;
		margin:0px;
	}
	.img-main2{
		visibility:hidden;
		height:0px !important;
		transition:all .5s ease;
		margin:0px;
	}
}
.sub-bar{
	margin-top:-5px !important;
}


.cont-1{
	margin-top:0px;
	margin-bottom:0px;
	padding-top:80px;
	padding-bottom:50px;
	background-color:rgb(16,17,19);
	min-height:100%;
}
.cont-1 .text-body,.panel{
	background:none;	
	font-size:1.1em;
}
.cont-1 blockquote{
	color:#ff0000 !important;
	font-style:bold !important;
	border:none !important;
	text-align:center;
	text-transform:uppercase;
}
.cont-1 span{
	padding-top:10px;
	text-align:center;
}
.cont-1 span a{
	color:#484848;
	border:1px solid #484848;
	padding:4px;
	border-radius:0%;
}

.cont-2{
	margin-top:0px;
	margin-bottom:0px;
	padding-top:80px;
	padding-bottom:50px;
	background-color:rgb(230,230,230);
	min-height:100%;
}
.cont-2 .text-body,.panel{
	background:none;	
	font-size:1.1em;
}
.cont-2 blockquote{
	color:#ff0000 !important;
	font-style:bold !important;
	border:none !important;
	text-align:center;
	text-transform:uppercase;
}
.cont-2 span{
	padding-top:10px;
	text-align:center;
}
.cont-2 span a{
	color:#484848;
	border:1px solid #484848;
	padding:4px;
	border-radius:0%;
}

.dropbtn {
  background-color: #3498DB;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

</style>

<?php include"bars/main_navbar.php"?>	
<?php include"slider.php"?>
<div style="width:100%;height:10px;background-color:#020202;margin-top:-10px;z-index:99"></div>
	<div class="my-body">	
		<div id="cont-1" class="cont-1">
			<div class="container">
				<div class="col-md-4 col-lg-4 col-sm-4 col-xs-12">
					<div class="col-md-12 panel">
						<img class="panel-img" src="images/deck1.jpg"></img>
						<div class="col-md-12">						
							<p class="text-body" style="color:#e8e8e8;">		
								<blockquote><b>Dj-Academy</b></blockquote>
								<span style="color:#c8c8c8;">
									<?php echo strip_tags(substr("Learn from one of the best DJ Training Academy in Kenya. Are you looking to start you career as a DJ or want to brush up your skills, we have got you covered at our academy. Probeatz Academy offers a full range of courses to suit everyone from the beginners to those looking to refine and enhance their skills. Whether you want to play for your own enjoyment or to make a career as a DJ or a Music Producer/Remixer.",0,200));?>...
								</span>	
							</p>
							<span class="col-md-12"><a href="page_academy.php" class=" btn-default">More <small><i class="glyphicon glyphicon-menu-right"></i></small></a></span>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-lg-4 col-sm-4 col-xs-12">
					<div class="col-md-12 panel">
						<img class="panel-img" src="images/1562785247192.jpg"></img>
						<div class="col-md-12">						
							<p class="text-body">	
								<blockquote><b>Mastering</b></blockquote>
								<span style="color:#c8c8c8;">
									<?php echo strip_tags(substr("Choose the best mastering studio for your projects. Our studios are fully equiped with all the high end tools neede to give you a audio mastering of the very highest statndard at flexible prices. Get mastering service suited to your budget without compromising on quality.",0,200));?>...
								</span>	
							</p>
							<span class="col-md-12"><a href="page_mastering.php" class=" btn-default"> More <small><i class="glyphicon glyphicon-menu-right"></i></small></a></span>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-lg-4 col-sm-4 col-xs-12">
					<div class="col-md-12 panel">
						<img class="panel-img" src="images/hqdefault.jpg"></img>
						<div class="col-md-12">						
							<p class="text-body" style="color:#e8e8e8 !important;">		
								<blockquote><b>Music Academy</b></blockquote>
								<span style="color:#c8c8c8;">
									<?php echo strip_tags(substr("Learn from one of the best music Training Academy in Kenya. Are you looking to start you career as a musician or want to brush up your skills, we have got you covered at our academy. Probeatz Academy offers a full range of courses to suit everyone from the beginners to those looking to refine and enhance their skills. Whether you want to play for your own enjoyment or to make a career as a DJ or a Music Producer/Remixer.",0,200));?>...
								</span>	
							</p>
							<span class="col-md-12"><a href="page_academy.php" class=" btn-default"> More <small><i class="glyphicon glyphicon-menu-right"></i></small></a></span>
						</div>
					</div>
				</div>	
			</div>
		</div>
		
		
		<div id="cont-2" class="cont-2">	
			<div class="container">
				<div class="col-md-4 col-lg-4 col-sm-4 col-xs-12">
					<div class="col-md-12 panel">
						<img class="panel-img" src="images/sounds3.jfif"></img>
						<div class="col-md-12">						
							<p class="text-body" style="color:#282828 !important;">	
								<blockquote><b>PA Hire</b></blockquote>
								<span>
									<?php echo strip_tags(substr("High quality audio and sound system to make your event unforgetable. PA systems for your event",0,100));?>...
								</span>	
							</p>
							<span class="col-md-12"><a href="page_hireservice.php"> More <small><i class="glyphicon glyphicon-menu-right"></i></small></a></span>
						</div>
					</div>
				</div>			
				<div class="col-md-4 col-lg-4 col-sm-4 col-xs-12">
					<div class="col-md-12 panel">
						<img class="panel-img" src="images/m.jpg"></img>
						<div class="col-md-12">						
							<p class="text-body" style="color:#282828 !important;">	
								<blockquote><b>Sound Hire</b></blockquote>
								<span>
									<?php echo strip_tags(substr("High quality audio and sound system to make your event unforgetable. Sound systems for your event",0,90));?>...
								</span>	
							</p>
							<span class="col-md-12"><a href="page_hireservice.php"> More <small><i class="glyphicon glyphicon-menu-right"></i></small></a></span>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-lg-4 col-sm-4 col-xs-12">
					<div class="col-md-12 panel">
						<img class="panel-img" src="images/fs/Studio-3848-1 - Copy.jpg"></img>
						<div class="col-md-12">						
							<p class="text-body" style="color:#282828 !important;">	
								<blockquote><b>Photo Studio</b></blockquote>
								<span>
									<?php echo strip_tags(substr("Professional studio potraits ,weddings and engagements,events,confrences and launches,product photography",0,88));?>...
								</span>	
							</p>
							<span class="col-md-12"><a href="page_photostudio.php"> More <small><i class="glyphicon glyphicon-menu-right"></i></small></a></span>
						</div>
					</div>
				</div>				
			</div>
		</div>	
	</div>
	<?php include"bars/footer.php"?>
<script>
	$(document).ready(function(){
		$(".dropdown").hover(            
			function() {
				$('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideDown("400");
				$(this).toggleClass('open');        
			},
			function() {
				$('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideUp("400");
				$(this).toggleClass('open');       
			}
		);
	});
</script>
<script>
	$(document).on('click', ':not(form)[data-confirm]', function(e){
		if(!confirm($(this).data('confirm'))){
			e.stopImmediatePropagation();
			e.preventDefault();
		}
	});

	$(document).on('submit', 'form[data-confirm]', function(e){
		if(!confirm($(this).data('confirm'))){
			e.stopImmediatePropagation();
			e.preventDefault();
		}
	});

	$(document).on('input', 'select', function(e){
		var msg = $(this).children('option:selected').data('confirm');
		if(msg != undefined && !confirm(msg)){
			$(this)[0].selectedIndex = 0;
		}
	});
</script>