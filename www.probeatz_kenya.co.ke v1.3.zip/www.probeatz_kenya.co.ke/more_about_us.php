<?php include"header.php"?>
<style>
.sub-navbar a:nth-child(17){
	color:#ff3545 !important;
	font-weight:bold;
	border-bottom:2px solid #ffffff;
}
.contact{
	background:#000;
}
.p-top li{
	font-weight:bold;
}
.pp-top li{
	display:inline-block;
	margin-right:40px;
}
</style>

<?php include"bars/main_navbar.php"?>
<?php 
	$imagep = "images/subnav/image.jpg";
	$titlep = "Contact Us";
?>
<?php include"bars/sub-navbar.php"?>	
<div class="body">
	<div class="container cont-num">	
		<div class="col-md-12 col-xs-12" style="padding-top:20px;padding-bottom:100px;">	
			<div class="contact">
				<div class="col-md-12 col-xs-12">
					<ul class="p-top" style="font-size:2.0em;padding:10px;padding-left:20px;font-family:calibri;">
						<strong style="color:#ff0000;"><label style="font-size:1.5em !important;">Contact Info</label></strong><br>
						<li><small style="font-family:calibri light;"> <span class="glyphicon glyphicon-phone" style="color:#ff0000;"></span> Phone Number : +254791111111 </small></li>
						<li><small style="font-family:calibri light;"> <span class="glyphicon glyphicon-envelope" style="color:#ff0000;"></span> test@gmail.com </small></li>
					</ul>
				</div>
				<div class="col-md-12 col-xs-12">
					<ul class="pp-top" style="font-size:1.5em;padding:10px;padding-left:20px;font-family:calibri;">
						<li><a href="#"><img src="images/fx/social-facebook" style="width:60px;"></a></li>
						<li><a href="#"><img src="images/fx/social-instagram" style="width:60px;"></a></li>
						<li><a href="#"><img src="images/fx/social-twitter" style="width:60px;border-radius:10px;"></a></li>
						<li><a href="#"><img src="images/fx/social-youtube" style="width:60px;border-radius:10px;"></a></li>
					</ul>
				</div>
			</div>		
		</div>
	</div>
</div>
<?php include"bars/footer.php"?>
<script>
	$(document).ready(function(){
		$(".dropdown").hover(            
			function() {
				$('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideDown("400");
				$(this).toggleClass('open');        
			},
			function() {
				$('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideUp("400");
				$(this).toggleClass('open');       
			}
		);
	});
</script>
<script>
	$(document).on('click', ':not(form)[data-confirm]', function(e){
		if(!confirm($(this).data('confirm'))){
			e.stopImmediatePropagation();
			e.preventDefault();
		}
	});

	$(document).on('submit', 'form[data-confirm]', function(e){
		if(!confirm($(this).data('confirm'))){
			e.stopImmediatePropagation();
			e.preventDefault();
		}
	});

	$(document).on('input', 'select', function(e){
		var msg = $(this).children('option:selected').data('confirm');
		if(msg != undefined && !confirm(msg)){
			$(this)[0].selectedIndex = 0;
		}
	});
</script>