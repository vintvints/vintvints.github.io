<?php include"header.php"?>
<style>
.sub-navbar a:nth-child(11){
	color:#ff3545 !important;
	font-weight:bold;
	border-bottom:2px solid #ffffff;
}
.contact{
	background:#000;
}
.title{
	color:#ff3545 !important;
	font-size:1.5em;
	font-weight:bold;
	border-bottom:2px solid #383838;
	padding-bottom:5px;
}
.music-body{
	padding-top:20px;
	padding-bottom:100px;
}
</style>

<?php include"bars/main_navbar.php"?>
<?php 
	$imagep = "images/subnav/image.jpg";
	$titlep = "Contact Us";
?>
<?php include"bars/sub-navbar.php"?>	
<div class="body">
	<div class="container cont-num">		
		<div class="col-md-9">
			<div class="row">
				<div class="col-md-3 col-xs-4" style="margin-bottom:10px;">
					<img src="images/fx/live.png" style="width:100%;margin-top:40px;border:0px solid #989898;box-shadow:0px 0px 0px 0px #a9a9a9;"/>	
				</div> 
				<!--div class="col-md-9  col-xs-12 music-body">	
					<p class="title"> Music Hub</p>	
				</div-->
			</div>
		</div>
		<?php include"fbside.php"?>	
	</div>	
</div>
<?php include"bars/footer.php"?>
<script>
	$(document).ready(function(){
		$(".dropdown").hover(            
			function() {
				$('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideDown("400");
				$(this).toggleClass('open');        
			},
			function() {
				$('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideUp("400");
				$(this).toggleClass('open');       
			}
		);
	});
</script>
<script>
	$(document).on('click', ':not(form)[data-confirm]', function(e){
		if(!confirm($(this).data('confirm'))){
			e.stopImmediatePropagation();
			e.preventDefault();
		}
	});

	$(document).on('submit', 'form[data-confirm]', function(e){
		if(!confirm($(this).data('confirm'))){
			e.stopImmediatePropagation();
			e.preventDefault();
		}
	});

	$(document).on('input', 'select', function(e){
		var msg = $(this).children('option:selected').data('confirm');
		if(msg != undefined && !confirm(msg)){
			$(this)[0].selectedIndex = 0;
		}
	});
</script>