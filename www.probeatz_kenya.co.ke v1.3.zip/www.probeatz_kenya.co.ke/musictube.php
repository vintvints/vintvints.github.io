<style>
body{
	background:#012323 !important;
	text-align:center;
	width:100%;
	height:100%;
	padding:0px;
	padding-top:5%;
	margin:0px;
	font-family:calibri;
}
.title{
	padding:40px;
	color:#ee0000;
	font-size:3.5em;
	font-weight:bold;
	padding-bottom:0px;
}
.sub-title{
	padding:10px;
	color:#ee0000;
	font-size:1.5em;
	font-weight:bold;
	margin-bottom:30px;
}
#count{
	background:none;
	font-size:1.2em;
}
</style>
<?php include"header.php"?>
<body>
	
	<div class="title">ProBeatz MusicTube</div>
	<div class="sub-title">Your Favorite Music Site</div>
	<div id="count" style="width:400px;height:100px;margin:0 auto;color:#ffffff;"> </div>
	<a href="index.php"><button class="btn btn-default">Go Back </button></a>
	<a href="http://localhost/sites/www.musictube.com/"><button class="btn btn-success">Continue Now </button></a>
</body>
<script>
	function clear1(){
		var countee = document.getElementById('count');
		countee.innerHTML = "Redirecting to ProBeatzmusictube.com in 5 Sec... ";
	}
	clear1();
</script>	
<script>
	function redirect(){
		
		window.location.href="http://localhost/0 sites/www.musictube.com/";
			
	}	
	setInterval (redirect, 5000);
</script>