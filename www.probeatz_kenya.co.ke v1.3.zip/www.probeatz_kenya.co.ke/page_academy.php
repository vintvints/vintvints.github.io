<?php include"header.php"?>
<style>
.sub-navbar a:nth-child(3){
	color:#ff3545 !important;
	font-weight:bold;
	border-bottom:2px solid #ffffff;
}
.title{
	color:#ffffff;
	font-size:1.4em;
	font-family:calibri;
	padding-top:20px;
}



@media (max-width: 568px) {
  .col-xs-12{
	text-align:center !important;
  }
}
.sub-active{
	color:#ff3545 !important;
}
.p-studio{
	padding:2px;
	border:1px solid #383838;
	margin:1px;
}

.slanting{
	//left:0px !important;
	//text-align:right !important;
	position:absolute;
	//background-image:-webkit-linear-gradient(130deg,#fc1515 100%,rgba(0,0,0,0)0%) !important;
}


</style>
<?php include"bars/main_navbar.php"?>
<?php 
	$imagep = "images/subnav/image.jpg";
	$titlep = "Dj Academy";
?>
<?php include"bars/sub-navbar.php"?>	
<div class="body">
	<div class="container cont-num">
		<div class="col-md-9">
			<div class="row">
				<div class="col-md-3 col-xs-4" style="margin-bottom:50px;">
					<img src="images/5222fec4375f8071fec813dbc4ee1107.jpg" style="width:100%;margin-top:40px;border:1px solid #989898;box-shadow:0px 1px 2px 1px #a9a9a9;"/>			
				</div> 
				<div class="col-md-9 col-xs-8 you-body" style="padding-top:0px;padding-bottom:20px;">						
					<div class="text col-md-12 col-xs-12">				
						<h2>DJ Academy</h2>
						Learn from one of the best DJ Training Academy in Kenya. Are you looking to start you career as a DJ or want to brush up your skills, we have got you covered at our academy. Probeatz Academy offers a full range of courses to suit everyone from the beginners to those looking to refine and enhance their skills. Whether you want to play for your own enjoyment or to make a career as a DJ or a Music Producer/Remixer.
					</div>	
				</div>
			</div>
			<div class="row">
				<div class="col-md-3 col-xs-4">
					<img src="images/hqdefault.jpg" style="width:100%;margin-top:40px;border:1px solid #989898;box-shadow:0px 1px 2px 1px #a9a9a9;"/>			
				</div> 
				<div class="col-md-9 col-xs-8 you-body" style="padding-top:0px;padding-bottom:10px;">						
					<div class="text col-md-12 col-xs-12">				
						<h2>Music Academy</h2>
						Learn from one of the best music Training Academy in Kenya. Are you looking to start you career as a musician or want to brush up your skills, we have got you covered at our academy. Probeatz Academy offers a full range of courses to suit everyone from the beginners to those looking to refine and enhance their skills. Whether you want to play for your own enjoyment or to make a career as a DJ or a Music Producer/Remixer.
					</div>	
				</div>
			</div>
		</div>
		<?php include"fbside.php"?>
	</div>
</div>
<?php include"bars/footer.php"?>