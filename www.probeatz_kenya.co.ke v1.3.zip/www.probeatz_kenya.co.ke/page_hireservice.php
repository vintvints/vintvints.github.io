<?php include"header.php"?>
<style>
.sub-navbar a:nth-child(7){
	color:#ff3545 !important;
	font-weight:bold;
	border-bottom:2px solid #ffffff;
}

.text{
	padding:14px;
	text-align:left;
	font-size:1.35em;
	font-family:calibri light;
}
.text ul{
	padding:20px !important;
	margin-left:40px !important;
}
.text ul li{
	font-size:1.4em;
}

.sub-active{
	color:#ff3545 !important;
}
.btn{
	color:#585858;
}
.mini-text{
	color:#484848;
	font-size:1.1em;
	padding-bottom:70px;
}
</style>
<?php include"bars/main_navbar.php"?>
<?php 
	$imagep = "images/subnav/image.jpg";
	$titlep = "PA Systems";
?>
<?php include"bars/sub-navbar.php"?>	
<div class="body">
	<div class="container cont-num">		
		<div class="col-md-9">
			<div class="row">
				<div class="col-md-3 col-xs-4" style="margin-bottom:0px;">
					<img src="images/sounds3.jfif" style="width:100%;margin-top:40px;border:1px solid #989898;box-shadow:0px 1px 2px 1px #a9a9a9;"/>							
				</div> 
				<div class="col-md-9 col-xs-8 you-body" style="padding-top:0px;padding-bottom:0px;">						
					<div class="text col-md-12 col-xs-12">
						<h2>Sound Systems For Hire</h2>
						High quality audio and sound system to make your event unforgetable
						<br>PA systems for your event<br>
						<b><a class="contact" href="more_about_us.php"> Contact Us</a></b>
						<br><br>								
					</div>						
				</div>
			</div>
			<div class="row">
				<div class="col-md-3 col-xs-4" style="margin-bottom:0px;">
					<img src="images/lights3.jpg" style="width:100%;margin-top:40px;border:1px solid #989898;box-shadow:0px 1px 2px 1px #a9a9a9;"/>							
				</div> 
				<div class="col-md-9 col-xs-8 you-body" style="padding-top:20px;padding-bottom:20px;">						
					<div class="text col-md-12 col-xs-12">
						<h2>Lighting</h2>		
						We rent out stage equipments and provide lighing services
						<b><br><a class="contact" href="more_about_us.php"> Contact Us</a></b>
					</div>						
				</div>
			</div>
			<div class="row">
				<div class="col-md-3 col-xs-4" style="margin-bottom:0px;">
					<img src="images/photographer-website-design-91250317.jpg" style="width:100%;margin-top:40px;border:1px solid #989898;box-shadow:0px 1px 2px 1px #a9a9a9;"/>							
				</div> 
				<div class="col-md-9 col-xs-8 you-body" style="padding-top:20px;padding-bottom:20px;">						
					<div class="text col-md-12 col-xs-12">
						<h2>Events coverage</h2>		
						Make your event memorable with high quality video and camera coverage services
						<b><br><a class="contact" href="more_about_us.php"> Contact Us</a></b>
					</div>						
				</div>
			</div>
		</div>
		<?php include"fbside.php"?>
	</div>
</div>
<?php include"bars/footer.php"?>