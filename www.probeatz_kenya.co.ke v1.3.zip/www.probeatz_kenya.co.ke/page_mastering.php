<?php include"header.php"?>
<style>
.sub-navbar a:nth-child(9){
	color:#ff3545 !important;
	font-weight:bold;
	border-bottom:2px solid #ffffff;
}
.text{
	padding:14px;
	text-align:left;
	font-size:1.35em;
	font-family:calibri light;
}
.text ul{
	padding:20px !important;
	margin-left:40px !important;
}
.text ul li{
	font-size:1.4em;
}

@media (max-width: 568px) {
  .col-xs-12{
	text-align:center !important;
  }
}
.sub-active{
	color:#ff3545 !important;
}
</style>	
<?php include"bars/main_navbar.php"?>
<?php 
	$imagep = "images/subnav/image.jpg";
	$titlep = "Mastering";
?>
<?php include"bars/sub-navbar.php"?>	
<div class="body">
	<div class="container cont-num">		
		<div class="col-md-9">
			<div class="row">
				<div class="col-md-3 col-xs-4" style="margin-bottom:10px;">
					<img src="images/deck3.jpeg" style="width:100%;margin-top:40px;border:1px solid #989898;box-shadow:0px 1px 2px 1px #a9a9a9;"/>	
				</div> 
				<div class="col-md-9 col-xs-8 you-body" style="padding-top:0px;padding-bottom:20px;">						
					<div class="text col-md-12 col-xs-12">
						<h2>Mastering</h2>
						Choose the best mastering studio for your projects. Our studios are fully equiped with all the high end tools neede to give you a audio mastering of the very highest statndard at flexible prices. Get mastering service suited to your budget without compromising on quality.
						<b><br><a class="contact" href="more_about_us.php"> Contact Us</a></b>
					</div>
				</div>
			</div>
		</div>
		<?php include"fbside.php"?>		
	</div>
</div>
<?php include"bars/footer.php"?>