<?php include"header.php"?>

<style>
.sub-navbar a:nth-child(5){
	color:#ff3545 !important;
	font-weight:bold;
	border-bottom:2px solid #ffffff;
}
.text{
	padding:14px;
	text-align:left;
	font-size:1.35em;
	font-family:calibri light;
}
.text ul{
	padding:20px !important;
	margin-left:40px !important;
}
.text ul li{
	font-size:1.4em;
}

@media (max-width: 800px) {
	.col-xs-12{
		text-align:center !important;
	}
	.p-studio{
		height:150px !important;
	}
}
.sub-active{
	color:#ff3545 !important;
}
.p-studio{
	padding:2px;
	border:1px solid #383838;
	margin:1px;
}
</style>
</style>
<?php include"bars/main_navbar.php"?>
<?php 
	$imagep = "images/subnav/image.jpg";
	$titlep = "Photo studio";
?>
<?php include"bars/sub-navbar.php"?>	
<div class="body">
	<div class="container cont-num">	
		<div class="col-md-9">
			<div class="row">
				<div class="col-md-3 col-xs-4" style="margin-bottom:50px;">
					<img src="images/fs/Studio-3848-1.jpg" style="width:100%;margin-top:40px;border:1px solid #989898;box-shadow:0px 1px 2px 1px #a9a9a9;"/>			
					<img src="images/_DSC4451.jpg" style="width:100%;margin-top:40px;border:1px solid #989898;box-shadow:0px 1px 2px 1px #a9a9a9;"/>			
				</div> 
				<div class="col-md-9 col-xs-8 you-body" style="padding-top:0px;padding-bottom:20px;">						
					<div class="text col-md-12 col-xs-12">
						<h2>Photo Studio</h2>
						<h2>Photoshoot Services</h2>
							<li>Professional Studio  portraits</li>
							<li>Weddings & Engagements</li>
							<li>Events, Conferences and Launches</li>
							<li>Product photography/eCommerce</li>
							<li>Documentary/Humanitarian</li>
							<li>Community projects</li>
						<br>
						<b><br><a class="contact" href="more_about_us.php"> Contact Us</a></b>
						<br>			
					</div>
				</div>
			</div>
		</div>
		<?php include"fbside.php"?>
	</div>
</div>
<?php include"bars/footer.php"?>