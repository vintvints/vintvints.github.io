<style>
#my-slider{
    z-index:900;
}
.item{ 
	margin:0px !important;
}
.item .col-md-12-dark{
	background:rgba(0,0,0,.82);
	margin:0px;
	padding-top:16%;	
	height:100%;
	border:0px solid #a8a8a8;
}
#my-slider .carousel-inner > .item {
    text-align: center;
    color: #fff;
	height: 100% !important;
	padding-top:0px;
}

#my-slider .carousel-inner > .item:nth-child(1) {
	background-image:url('images/fs/online_servis_studio_music');
	background-size:100% 100% !important;	
	//filter:blur(1px);
}
#my-slider .carousel-inner > .item:nth-child(2) {
	background-image:url('images/deck1.jpg');
	background-size:100% 100% !important;	
}
#my-slider .carousel-inner > .item:nth-child(3) {
	background-image:url('images/fs/Studio-3848-1 - Copy.jpg');
	background-size:100% 100% !important;	
}
#my-slider .carousel-inner > .item:nth-child(4) {
	background-image:url('images/studiopic.jpg');
	background-size:100% 100% !important;	
}
	
@media(max-width:700px){
	#my-slider .carousel-inner > .item {
		height: 380px;
	}
	#my-slider .my-slider-title{
		font-size: 2.0em !important;
	}
	
	.img-12{
		margin-top:20% !important;
	}
	.img-121{
		margin-top:20% !important;
	}
}

#my-slider .my-slider-title{
    font-size: 4.0em;
	font-weight:bold;
	font-family:calibri light;
	text-transform: none;
    color: #fff;
}
.image-body{
	border:1px solid #585858;
	background:rgb(20,20,20,.3);
	border-radius:2px;
	padding:2px;
	height:160px;
}
.slider-image{
	width:100%;
	height:100%;
	border:1px solid #585858;
}
.slider-body{
	text-align:left;
	padding-top:10px;
}
.slider-body .text-title{
	font-size: 2.0em;
	font-weight:bold;
	font-family:calibri;
	text-transform: none;
    color: #fff;
}
.slider-body .text-body{
	font-size: 1.2em;
	font-family:calibri light;
	text-transform: none;
    color: #fff;
}
.slider-body .slider-btn{
	display: inline-block;
    color: rgb(16,17,19) !important;
    text-transform: uppercase;
    padding: 10px 20px 10px 20px;
    text-align: left;
	font-style:bold;
	margin-top:0px;
	text-decoration:none;
    border: 1px solid #f8f8f8 !important;
    font-size: 12px;
    line-height: 100%;
	background:#ffffff;
	border-radius:1px;
	font-weight:bold !important;
}
</style>
<img src="images/6 copy" class="xs-hidden md-hidden" style="width:100%;min-height:300px;transition:all 1s ease;"/>
<div id="my-slider" class="" style="transition:all 1s ease;z-index:1;">
	<div id="my-slider-inner">		
		<div id="my-slider" class="carousel slide" data-ride="carousel">            
			<div class="carousel-inner" role="listbox" style="height:100%;">
				<div class="item active">
					<div class="col-md-12 col-md-12-dark">
						<div class="container">
							<div class="col-md-12">
								<div class="slider-body" style="text-align:center;">
									<span class="text-title" style="font-size:3em;font-family:broadway light;margin-top:20px !important;margin-top:-40px;">	
										<img class="slider-image img-12" src="images/6 copy" style="height:200px;width:550px;padding:1px;margin-left:0 auto;"/>
										<br>
										<div id="inner"></div>
									</span>	
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="item">
					<div class="col-md-12 col-md-12-dark">
						<div class="container">
							<div class="col-md-12 slider">
								<div class="col-md-3 col-xs-12">
									<div class="image-body img-121"><img class="slider-image" src="images/325057"/></div>
								</div>
								<div class="col-md-9 col-xs-12">
									<div class="slider-body">
										<p class="text-title">	DJ ACADEMY</p>
										<p class="text-body xs-hidden">
											#Learn from the best
										</p>
										<a href="page_djacademy.php" class="slider-btn">Learn more <i class="glyphicon glyphicon-menu-right"></i></a>										
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="item">
					<div class="col-md-12 col-md-12-dark">
						<div class="container">
							<div class="col-md-12">
								<div class="col-md-3 col-xs-12">
									<div class="image-body img-121"><img class="slider-image" src="images/photographer-website-design-91250317.jpg"/></div>
								</div>
								<div class="col-md-9 col-xs-12">
									<div class="slider-body">
										<p class="text-title">	PHOTO STUDIO</p>
										<p class="text-body xs-hidden">
											#Learn from the best
										</p>
										<a href="page_photostudio.php" class="slider-btn">Learn more <i class="glyphicon glyphicon-menu-right"></i></a>										
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="item">
					<div class="col-md-12 col-md-12-dark">
						<div class="container">
							<div class="col-md-12">
								<div class="col-md-3 col-xs-12">
									<div class="image-body img-121"><img class="slider-image" src="images/deck3.jpeg"/></div>
								</div>
								<div class="col-md-9 col-xs-12">
									<div class="slider-body">
										<p class="text-title">	Mastering</p>
										<p class="text-body xs-hidden">
											#Learn from the best
										</p>
										<a href="page_mastering.php" class="slider-btn">Learn more <i class="glyphicon glyphicon-menu-right"></i></a>										
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>				
			</div>
			<style>
				.slider-bar-container{
					position:absolute;
					bottom:100px;
					z-index:100;
					width:100%;
					text-align:center;
					background:none;
					padding-top:20px;
				}
				.slider-bar li{
					display:inline-block;
					
				}
				.slider-bar-container .slider-bar li{
					border:1px solid #020202;
					box-shadow:0px 1px 2px 0px #000;
					border-radius:1px;
					margin:3px;
					background-color:rgb(255,0,0,.9);
					min-width:150px;
					padding:10px;
					opacitiy:0.8;
				}
				.slider-bar-container .slider-bar li:nth-child(1){
					background-color:rgb(0,0,0,.8);
				}
				.slider-bar-container .slider-bar li a{
					font-size:1.2em;
					color:#f8f8f8;
					font-family:calibri light;
					background:none;
					margin:0px;
					width:100px;
					//background:rgb(0,0,0,.8);
				}
				.carousel-indicators{
					
				}
				.carousel-indicators li{
					background:#020202;
					border:1px solid #989898;
					padding:0px !important;
					margin:0px !important;
					z-index:100;
				}
								
				.carousel-indicators li a{
					position:relative;
					text-align:center;
					z-index:1000;
				}
			</style>
			<div class="container slider-bar-container">
				<ul class="slider-bar">
					<li title="Home" style="background:#ff0000 !important;"><a href="index.php"> <i class="glyphicon glyphicon-home"></i> Home</a></li> 
					<li title="Listen and Download Your Favourite music" style="background:#151515 !important;"><a href="music.php"><i class="glyphicon glyphicon-music"></i> Music</a></li>
					<li  title="Contact Us" style="background:#151515 !important;"><a href="more_about_us.php"><i class="glyphicon glyphicon-globe"></i> Contact Us</a></li>
				</ul>			
			</div>			
			<ul class="carousel-indicators">
				<li class="active"></li> 
				<li></li> 
				<li></li> 
				<li></li> 
			</ul>
		</div>
	</div>
</div>
	
	
	<style>
.side-indicators{
	position:fixed;
	left:20px;
	top:45%;
	z-index:1000;
}
.side-indicators ul li{
	list-style-type:none;
	margin:3px;
	width:10px;
	height:10px;	
	background:#020202 !important;
	border:1px solid #a8a8a8 !important;
	border-radius:50%;
}

.li-1 li:nth-child(1){
	background:#f8f8f8 !important;
	border:1px solid #121212 !important;
	width:11px;
	height:11px
}
.li-2 li:nth-child(2){
	background:#f8f8f8 !important;
	border:1px solid #121212 !important;
	width:11px;
	height:11px
}
.li-3 li:nth-child(3){
	background:#f8f8f8 !important;
	border:1px solid #121212 !important;
	width:11px;
	height:11px
}
.li-4 li:nth-child(4){
	background:#f8f8f8 !important;
	border:1px solid #121212 !important;
	width:11px;
	height:11px
}
</style>


<div class="side-indicators">
	<ul class="li-1" id="side-indicators-ul">		
		<li></li>
		<li> </li>
		<li> </li>
		<li> </li>
	</ul>	
</div>